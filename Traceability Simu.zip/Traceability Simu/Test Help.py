from os import stat
import clr
import time

###this is an example of how to call functions with code###

#These names are kept because they are from the original .dll for the traceability system
newtonsoftjson_path = r"C:\Traceability Simu\LINQtoCSV.dll" 
wsconnector_path = r"C:\Traceability Simu\WSConnectorSimu.dll"

clr.AddReference(newtonsoftjson_path)
clr.AddReference(wsconnector_path)

#PCB information example  ***Comments with asterisks indicate where the data comes from***
partnumber = ""  #***Set in the script***
serial = "A00006421124T1"  #***The operator enters it***
station_name = "STA_FNLFUNC193" #***Set in the script***
process = "TEST FINAL FUNCTIONAL" #***Set in the script***  
status = 1 #choice 0 if failed test or 1 if passed test ***
#if status is 1, fail string is "", if is 0, string is how the example  ***The test program sends it at the end of the test***
fail_string = "" #if is fail = "|ftestres=0,'FUNCTIONAL TEST + BLOCKING'-'TEST SIGNAL CFC'-'CFC = 0-CFR=0-EFL=0-EFH=0',0.8634312,260.0,200.0,230.0,tbd,<>"  This is a example of fail ***The test program sends it at the end of the test***
employee = "Test Simu"  #***set in the script or operator enters it, depends on the station or if login is required***
#in the original is "from WSConnector import Connector"
from WSConnectorSimu import Connector

connector = Connector()
test_start_time = connector.CIMP_GetDateTimeStr() #Start time ***Obtained from the dll***
time.sleep(3) #Simulate time of the test
test_end_time = connector.CIMP_GetDateTimeStr() #Final time ***Obtained from the dll***
print("1.-CIMP_PartNumberRef")
print("2.-BackCheck_Serial")
print("3.-InsertProcessDataWithFails")
choice = input("What function do you want to test? ")
if choice == '1':
    reply = connector.CIMP_PartNumberRef(serial, 1, partnumber) #connector.CIMP_PartNumberRef(string SerialNumber, int BCTYPE, ref string AssemblyPartNumber) in .dll original
    print (reply)
elif  choice == '2':
    reply = connector.BackCheck_Serial(serial, station_name) #connector.BackCheck_Serial(string _serialNumber, string _stationName) in .dll original
    print (reply)
elif choice == '3':
    reply = connector.InsertProcessDataWithFails(serial,station_name,process,test_start_time,test_end_time,status,fail_string,employee) #connector.InsertProcessDataWithFails(string ser_num, string station_name, string function, string ent_time, string ext_time, int pass_fail, string fail_string, string employee)
    print (reply)
else:
    print ("select correct option")

    