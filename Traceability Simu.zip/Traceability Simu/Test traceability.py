from os import stat
import clr
import time

###this is an small example of test in the station, 

#These names are kept because they are from the original .dll for the traceability system
newtonsoftjson_path = r"C:\Traceability Simu\LINQtoCSV.dll" 
wsconnector_path = r"C:\Traceability Simu\WSConnectorSimu.dll"

clr.AddReference(newtonsoftjson_path)
clr.AddReference(wsconnector_path)

#Set up variables to be used in the program
partnumber = "2H24480+G"
StationName = "STA_FNLFUNC193"
function = "TEST FINAL FUNCTIONAL"

connector = Connector() #Create clase
#first step: Enter Serial
serial = "A00006421124T1"
serial_partnumber = ""
replyPartNumber, serial_partnumber = connector.CIMP_PartNumberRef(serial,1, serial_partnumber)
if serial_partnumber == partnumber:
    #step two: Backcheck
    replyBackCheck = connector.BackCheck_Serial(serial, StationName)
    if replyBackCheck == "1|TEST FINAL FUNCTIONAL":
        #step three: Request the start time (initial).
        test_start_time = connector.CIMP_GetDateTimeStr()
        #Step four: Do the Test Sequence for the UUT, in this case, the pcb passed the test
        time.sleep(3) #Simulate time of the test sequence
        passfail = 1 
        fail_string = ""
        #Step five: Request the Final time.
        test_end_time = connector.CIMP_GetDateTimeStr()
        #Step six: Send the Test Results to the Traceability System
        replyInsert = connector.InsertProcessDataWithFails(serial, StationName, function, test_start_time, test_end_time, passfail, fail_string, "employee")
        if replyInsert == "OK":
            print("TEST FUNCTIONAL PASSED")
            #end
        else:
            print("Fail to uploaded to traceability" + replyInsert)
    else:
        print("Fail Backcheck" + replyBackCheck)
else:
    print("PartNumber incorrect, take a new pcb")